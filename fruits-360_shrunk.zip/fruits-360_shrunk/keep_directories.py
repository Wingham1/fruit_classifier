import os
import shutil

to_keep = ['Apple Crimson Snow', 'Apple Granny Smith', 'Apricot', 'Avocado ripe', 'Banana', 'Beetroot', 'Blueberry',
'Cauliflower', 'Cocos', 'Dates', 'Eggplant', 'Ginger Root', 'Kiwi', 'Lemon', 'Limes', 'Onion White', 'Orange',
'Pepper Yellow', 'Pineapple', 'Strawberry', 'Tomato 4']
sets = ['Test', 'Training']

# remove the unwanted classes from the data sets
for set in sets:
    path = os.path.join('.', set)
    for dir in os.listdir(path):
        if dir not in to_keep:
            shutil.rmtree(os.path.join(path, dir))

# test it
for set in sets:
    if len(os.listdir(os.path.join('.', set))) == len(to_keep):
        print('number of classes in {} set is correct'.format(set))
    else:
        print('number of classes in {} set does not match the number of wanted classes!'.format(set))
